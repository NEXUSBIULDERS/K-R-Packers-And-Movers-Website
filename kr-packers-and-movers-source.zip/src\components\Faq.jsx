import React, { useState } from 'react';
import { ChevronDown, PhoneCall } from 'lucide-react';
import { faqData } from '../data/faqData';
import { companyData } from '../data/companyData';

export default function Faq() {
  const [openIndex, setOpenIndex] = useState(0);

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 lg:py-28 bg-white border-t border-slate-200/60">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#0057B8] bg-blue-50 px-3.5 py-1.5 rounded-full mb-3">
            Common Inquiries
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Everything you need to know about shifting schedules, packaging methods, pricing, and transit safety.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4">
          {faqData.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-[#F8FAFC] rounded-2xl border border-slate-200/90 overflow-hidden shadow-soft transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(index)}
                  className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span className="font-bold text-base sm:text-lg text-[#1E293B] flex items-center gap-3">
                    <span className="text-xs font-extrabold text-[#0057B8] bg-white w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center shrink-0">
                      0{index + 1}
                    </span>
                    {item.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-600 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 bg-blue-50 text-[#0057B8]' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-slate-600 text-sm sm:text-base leading-relaxed border-t border-slate-100">
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still Have Questions CTA */}
        <div className="mt-12 text-center p-8 bg-blue-50/60 rounded-2xl border border-blue-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="font-bold text-slate-900 text-base">Have a question not listed here?</h4>
            <p className="text-xs text-slate-600 mt-0.5">Our Kerala move advisors are available 24 hours a day to assist you.</p>
          </div>
          <a
            href={`tel:${companyData.phoneClean}`}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004694] shrink-0 transition-colors shadow-xs"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call Helpline</span>
          </a>
        </div>
      </div>
    </section>
  );
}
