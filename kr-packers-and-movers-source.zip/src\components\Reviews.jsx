import React from 'react';
import { Star, Quote, CheckCircle2 } from 'lucide-react';
import { reviewsData } from '../data/reviewsData';

export default function Reviews() {
  return (
    <section id="reviews" className="py-20 lg:py-28 bg-white border-y border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#0057B8] bg-blue-50 px-3.5 py-1.5 rounded-full mb-3">
            Client Testimonials
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Trusted by Thousands Across Kerala
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Read what our genuine customers have to say about their experience moving with K R Packers &amp; Movers.
          </p>

          {/* Aggregate Rating Pill */}
          <div className="inline-flex items-center gap-2 mt-6 px-4 py-2 rounded-full bg-slate-50 border border-slate-200">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <span className="text-xs font-bold text-slate-800">4.9 / 5.0 Rating</span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500">Based on 1,450+ Verified Kerala Reviews</span>
          </div>
        </div>

        {/* Three Review Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviewsData.map((review) => (
            <div
              key={review.id}
              className="bg-[#F8FAFC] rounded-2xl p-8 border border-slate-200/90 shadow-soft shadow-soft-hover flex flex-col justify-between"
            >
              <div>
                {/* Top: Stars and Quote icon */}
                <div className="flex items-center justify-between mb-5">
                  <div className="flex text-amber-400">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-blue-200/80" />
                </div>

                {/* Service Tag */}
                <span className="inline-block text-[11px] font-semibold text-[#0057B8] bg-blue-50 px-2.5 py-0.5 rounded-md mb-3">
                  {review.serviceType}
                </span>

                {/* Comment */}
                <p className="text-sm text-slate-700 leading-relaxed italic mb-6">
                  "{review.comment}"
                </p>
              </div>

              {/* Customer Info */}
              <div className="pt-5 border-t border-slate-200/80 flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#0057B8] text-white flex items-center justify-center font-bold text-xs shrink-0">
                  {review.avatarInitial}
                </div>
                <div className="overflow-hidden">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-sm text-[#1E293B] truncate">
                      {review.name}
                    </h4>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" title="Verified Customer" />
                  </div>
                  <p className="text-xs text-slate-500 truncate">
                    {review.role}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
