import React from 'react';
import { Award, Users, Tag, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';

export default function About() {
  const aboutCards = [
    {
      title: "10+ Years Experience",
      description: "Over a decade of trusted shifting services navigating every route across Kerala and southern states with proven dependability.",
      icon: Award,
      badge: "Established 2014"
    },
    {
      title: "Professional Team",
      description: "Trained in-house packers, verified drivers, and cautious handlers equipped with specialized loading dollies and protective equipment.",
      icon: Users,
      badge: "150+ Crew Members"
    },
    {
      title: "Affordable Pricing",
      description: "Honest, transparent quotations tailored to your exact inventory and volume with zero surprise extra costs or hidden taxes.",
      icon: Tag,
      badge: "Guaranteed Fair Rates"
    },
    {
      title: "Safe Delivery",
      description: "Zero compromise on safety using multi-tier corrugated cushioning, waterproof shrink wrap, and padded enclosed vehicles.",
      icon: ShieldCheck,
      badge: "Damage Protection"
    }
  ];

  return (
    <section id="about" className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#0057B8] bg-blue-50 px-3.5 py-1.5 rounded-full mb-3">
            About K R Packers &amp; Movers
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Kerala's Most Reliable Relocation Partner
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Founded with a commitment to eliminate shifting anxiety, K R Packers &amp; Movers has grown into one of Kerala's foremost packing and logistics companies.
          </p>
        </div>

        {/* Company Narrative & Feature Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-6 space-y-5 text-slate-700 leading-relaxed">
            <h3 className="text-2xl font-bold text-[#1E293B]">
              Streamlining Relocations with Care, Precision, and Integrity
            </h3>
            <p>
              Whether you are moving a 1 BHK apartment in Ernakulam, shifting an entire corporate branch in Thiruvananthapuram Technopark, or relocating to Kozhikode, K R Packers &amp; Movers handles every asset as if it were our own.
            </p>
            <p>
              We replace guesswork with structured planning. Our move managers conduct preliminary inventory evaluations, provide written time estimates, and deploy modern enclosed container trucks operated by experienced drivers who know Kerala roads inside out.
            </p>
            
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm font-medium text-slate-800">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF7A00] shrink-0" />
                <span>Custom Crating for Antiques</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF7A00] shrink-0" />
                <span>GPS Tracked Moving Trucks</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF7A00] shrink-0" />
                <span>Full Assembly &amp; Placement</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF7A00] shrink-0" />
                <span>Full Transit Insurance Facility</span>
              </div>
            </div>

            <div className="pt-4">
              <a
                href="#services"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0057B8] hover:text-[#004694] group"
              >
                <span>Explore all moving services</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>

          {/* Visual Showcase Card */}
          <div className="lg:col-span-6">
            <div className="relative rounded-2xl overflow-hidden shadow-soft border border-slate-200/80 bg-white p-3">
              <img
                src="https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=800&q=80"
                alt="Packers and Movers packaging supplies and boxes"
                className="w-full h-80 object-cover rounded-xl"
                loading="lazy"
                decoding="async"
                width="800"
                height="320"
              />
              <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white">
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Direct Company-Owned Fleet</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Operated by full-time staff across Kerala</p>
                </div>
                <a
                  href="#quote"
                  className="inline-flex items-center justify-center px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#0057B8] hover:bg-[#004694] transition-colors"
                >
                  Book Your Move
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Cards Required by Specification */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {aboutCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl p-7 border border-slate-200/90 shadow-soft shadow-soft-hover flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#0057B8] flex items-center justify-center mb-5">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="inline-block text-[11px] font-bold uppercase tracking-wider text-[#FF7A00] mb-2">
                    {card.badge}
                  </span>
                  <h3 className="text-xl font-bold text-[#1E293B] mb-2.5">
                    {card.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {card.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
