export const servicesData = [
  {
    id: "house-shifting",
    title: "House Shifting",
    shortDesc: "Complete door-to-door household relocation with multi-layer wrapping for all furniture, kitchenware, and electronics.",
    features: [
      "Custom carton packing for delicate chinaware",
      "Dismantling and reassembly of beds & wardrobes",
      "Floor and doorway protection during shifting",
      "Dedicated covered container trucks"
    ],
    iconName: "Home",
    badge: "Most Popular"
  },
  {
    id: "office-relocation",
    title: "Office Relocation",
    shortDesc: "Minimal downtime commercial moving for IT firms, corporate offices, banks, and retail shops across Kerala.",
    features: [
      "Anti-static packing for servers & desktop PCs",
      "Organized desk numbering & inventory tags",
      "Weekend and after-hours shifting availability",
      "Document vault and file cabinet security"
    ],
    iconName: "Building2",
    badge: "Corporate"
  },
  {
    id: "packing",
    title: "Packing",
    shortDesc: "High-grade 5-layer corrugated sheets, bubble wrap, stretch film, and wooden crating for maximum transit safety.",
    features: [
      "Heavy-duty corrugated boxes and wardrobe boxes",
      "Multi-layer air bubble cushion protection",
      "Specialized wooden crates for fragile antiques",
      "Clear labeling with room & content tags"
    ],
    iconName: "PackageCheck",
    badge: "Premium Materials"
  },
  {
    id: "unpacking",
    title: "Unpacking",
    shortDesc: "Careful unpacking, inspection, and systematic room-by-room placement of household goods at your new destination.",
    features: [
      "Systematic unpack based on color-coded labels",
      "Assistance in furniture and appliance placement",
      "Immediate physical condition verification",
      "Eco-friendly debris removal and box disposal"
    ],
    iconName: "PackageOpen",
    badge: "Stress-Free"
  },
  {
    id: "loading",
    title: "Loading",
    shortDesc: "Trained ground crew utilizing hydraulic ramps, lifting dollies, and safety straps to load goods systematically.",
    features: [
      "Even weight distribution inside the truck",
      "Heavy appliance dollies & padded straps",
      "No dragging or scraping across floor surfaces",
      "Supervised by dedicated moving team lead"
    ],
    iconName: "ArrowUpRightSquare",
    badge: "Trained Crew"
  },
  {
    id: "unloading",
    title: "Unloading",
    shortDesc: "Precise and careful unloading from vehicles directly into the designated rooms of your apartment or villa.",
    features: [
      "Staircase and elevator handling expertise",
      "Gentle handling of fragile and high-value cargo",
      "Immediate inventory sheet cross-check",
      "Zero drop damage guarantee"
    ],
    iconName: "ArrowDownLeftSquare",
    badge: "Safe Handling"
  },
  {
    id: "vehicle-transport",
    title: "Vehicle Transport",
    shortDesc: "Enclosed hydraulic car carrier trailers and custom bike stands for scratch-free inter-city and inter-state transit.",
    features: [
      "Dedicated wheel chocks & tie-down harness",
      "Pre-loading photo inspection & condition report",
      "Real-time GPS vehicle location tracking",
      "Door-to-door pickup and drop-off facility"
    ],
    iconName: "Truck",
    badge: "Enclosed Carriers"
  },
  {
    id: "warehouse-storage",
    title: "Warehouse Storage",
    shortDesc: "Clean, pest-controlled, CCTV-monitored secure storage facilities for short-term and long-term storage needs.",
    features: [
      "24/7 CCTV surveillance & fire suppression systems",
      "Moisture-proof and pest-controlled environment",
      "Flexible weekly, monthly, or yearly rentals",
      "Full insurance coverage for stored inventory"
    ],
    iconName: "Warehouse",
    badge: "24/7 Monitored"
  }
];
