import React from 'react';
import {
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  ExternalLink
} from 'lucide-react';
import { companyData } from '../data/companyData';

export default function Contact() {
  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#FF7A00] bg-orange-50 px-3.5 py-1.5 rounded-full mb-3">
            Get in Touch
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Contact K R Packers &amp; Movers
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Reach out through call, WhatsApp, or visit our central offices across Kerala. We are ready to assist you 24×7.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Details Cards */}
          <div className="lg:col-span-5 space-y-6">
            {/* Phone Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-soft flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#0057B8] flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Phone Numbers (24x7)
                </span>
                <div className="mt-1 space-y-1">
                  <a
                    href={`tel:${companyData.phoneClean}`}
                    className="block font-bold text-base text-[#1E293B] hover:text-[#0057B8] transition-colors"
                  >
                    {companyData.phone}
                  </a>
                  <a
                    href={`tel:${companyData.phoneSecondary.replace(/\s+/g, '')}`}
                    className="block text-sm font-semibold text-slate-600 hover:text-[#0057B8] transition-colors"
                  >
                    {companyData.phoneSecondary}
                  </a>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Toll-free booking &amp; emergency move coordination
                </p>
              </div>
            </div>

            {/* WhatsApp Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-soft flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Instant WhatsApp Chat
                </span>
                <div className="mt-1">
                  <a
                    href={companyData.whatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 font-bold text-base text-emerald-600 hover:text-emerald-700 transition-colors"
                  >
                    <span>{companyData.phone}</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Share photos or videos of your items for quick instant estimates
                </p>
              </div>
            </div>

            {/* Email Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-soft flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-orange-50 text-[#FF7A00] flex items-center justify-center shrink-0">
                <Mail className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Email Inquiries
                </span>
                <div className="mt-1 space-y-0.5">
                  <a
                    href={`mailto:${companyData.email}`}
                    className="block font-bold text-sm text-[#1E293B] hover:text-[#0057B8] transition-colors"
                  >
                    {companyData.email}
                  </a>
                  <a
                    href={`mailto:${companyData.supportEmail}`}
                    className="block text-xs text-slate-600 hover:text-[#0057B8] transition-colors"
                  >
                    {companyData.supportEmail}
                  </a>
                </div>
                <p className="text-xs text-slate-500 mt-1.5">
                  Official corporate quotes &amp; invoice communications
                </p>
              </div>
            </div>

            {/* Address Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-soft flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6 text-[#0057B8]" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Central Kerala Head Office
                </span>
                <p className="mt-1 font-bold text-sm text-[#1E293B]">
                  {companyData.mainOffice.addressLine1}
                </p>
                <p className="text-xs text-slate-600">
                  {companyData.mainOffice.addressLine2}
                </p>
                <div className="mt-3 flex items-center gap-1.5 text-xs text-emerald-600 font-semibold">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{companyData.mainOffice.hours}</span>
                </div>
              </div>
            </div>

            {/* Regional Hubs Pill List */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs text-slate-700">
              <span className="font-bold text-[#0057B8] block mb-2">Regional Operational Hubs:</span>
              <div className="grid grid-cols-2 gap-2 text-slate-600">
                <div>• Kochi: Edappally &amp; Kakkanad</div>
                <div>• Trivandrum: Kazhakoottam</div>
                <div>• Kozhikode: Mavoor Road</div>
                <div>• Thrissur: Puzhakkal</div>
              </div>
            </div>
          </div>

          {/* Google Maps Embed Card */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-soft overflow-hidden h-full flex flex-col">
              <div className="flex items-center justify-between pb-3 px-2 border-b border-slate-100 mb-3">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#FF7A00]" />
                  <span className="text-sm font-bold text-slate-800">
                    Kochi Relocation Hub &amp; Fleet Yard
                  </span>
                </div>
                <span className="text-[11px] font-medium text-slate-500">
                  Edappally Toll, Ernakulam
                </span>
              </div>

              {/* Map Iframe */}
              <div className="relative w-full h-[420px] lg:h-[480px] rounded-xl overflow-hidden bg-slate-100">
                <iframe
                  title="K R Packers and Movers Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3928.653496030953!2d76.3056461757833!3d10.029806490077465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b080d96d98f9219%3A0xe54e153f3e790ec3!2sEdappally%20Toll%2C%20Edappally%2C%20Kochi%2C%20Kerala%20682024!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                ></iframe>
              </div>

              <div className="pt-3 px-2 flex items-center justify-between text-xs text-slate-500">
                <span>Free parking available for inventory consultation</span>
                <a
                  href="https://maps.google.com/?q=Edappally+Toll+Kochi+Kerala"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-[#0057B8] hover:underline inline-flex items-center gap-1"
                >
                  <span>Open in Google Maps</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
