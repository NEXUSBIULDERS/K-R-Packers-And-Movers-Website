export const companyData = {
  name: "K R Packers & Movers",
  tagline: "Professional Packers & Movers Across Kerala",
  experienceYears: "10+",
  phone: "+91 62825 59957",
  phoneSecondary: "+91 94460 54321",
  phoneClean: "+916282559957",
  whatsappNumber: "+91 62825 59957",
  whatsappClean: "916282559957",
  whatsappLink: "https://wa.me/916282559957?text=Hello%20K%20R%20Packers%20%26%20Movers%2C%20I%20would%20like%20to%20get%20a%20free%20relocation%20quote.",
  email: "info@krpackersmovers.com",
  supportEmail: "support@krpackersmovers.com",
  mainOffice: {
    addressLine1: "Metro Pillar 384, Edappally Toll Junction",
    addressLine2: "Kochi, Ernakulam, Kerala - 682024",
    hours: "Open 24/7 (Mon - Sun)"
  },
  regionalHubs: [
    { city: "Kochi", area: "Edappally & Kakkanad Infopark" },
    { city: "Thiruvananthapuram", area: "Technopark Bypass & Kazhakoottam" },
    { city: "Kozhikode", area: "Mavoor Road & Hilite City" },
    { city: "Thrissur", area: "Puzhakkal & Swaraj Round" }
  ],
  socialLinks: {
    facebook: "https://facebook.com",
    instagram: "https://instagram.com",
    youtube: "https://youtube.com",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  }
};
