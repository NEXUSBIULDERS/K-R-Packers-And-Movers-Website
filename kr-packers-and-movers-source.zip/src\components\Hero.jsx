import React from 'react';
import { Phone, ArrowRight, ShieldCheck, CheckCircle2, Clock } from 'lucide-react';
import { companyData } from '../data/companyData';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[620px] lg:min-h-[700px] flex items-center justify-center bg-slate-900 text-white overflow-hidden">
      {/* Background Image with Dark Professional Overlay */}
      <div className="absolute inset-0 z-0">
        <picture>
          <source
            media="(max-width: 640px)"
            srcSet="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=750&q=80"
          />
          <source
            media="(max-width: 1024px)"
            srcSet="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1280&q=80"
          />
          <img
            src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1600&q=80"
            alt="K R Packers and Movers Transport Truck on Road"
            className="w-full h-full object-cover object-center transform scale-105"
            loading="eager"
            fetchPriority="high"
            decoding="async"
            width="1600"
            height="900"
          />
        </picture>
        {/* Subtle dual gradient overlay ensuring perfect typography contrast without glassmorphism */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-900/85 to-slate-900/70" />
        <div className="absolute inset-0 bg-[#0057B8]/20 mix-blend-multiply" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 w-full">
        <div className="max-w-3xl">
          {/* Location / Trust Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-white/20 text-white text-xs sm:text-sm font-medium mb-6">
            <span className="w-2 h-2 rounded-full bg-[#FF7A00] animate-pulse" />
            <span>Kerala's #1 Rated Relocation Experts</span>
            <span className="text-white/40">|</span>
            <span className="text-slate-200">100% Safe Transit</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.15] mb-6 text-white">
            Moving Made Easy.
          </h1>

          {/* Subheading */}
          <p className="text-lg sm:text-xl lg:text-2xl text-slate-200 font-normal leading-relaxed mb-6 max-w-2xl">
            Professional Packers &amp; Movers Across Kerala.
          </p>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-10 max-w-xl">
            From seamless household shifting to corporate office transfers and vehicle transport, experience hassle-free relocation backed by verified staff and modern GPS-tracked fleets.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <a
              href={`tel:${companyData.phoneClean}`}
              className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl text-base font-semibold text-white bg-[#FF7A00] hover:bg-[#E56E00] active:scale-[0.98] shadow-md transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FF7A00]"
            >
              <Phone className="w-5 h-5" />
              <span>Call Now</span>
            </a>
            <a
              href="#quote"
              className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl text-base font-semibold text-white bg-[#0057B8] hover:bg-[#004694] active:scale-[0.98] border border-blue-400/30 shadow-md transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <span>Get Free Quote</span>
              <ArrowRight className="w-5 h-5 text-orange-300" />
            </a>
          </div>

          {/* Quick Value Points */}
          <div className="mt-12 pt-8 border-t border-white/15 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs sm:text-sm text-slate-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#FF7A00] shrink-0" />
              <span>No Hidden Charges</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#FF7A00] shrink-0" />
              <span>Damage Protection</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#FF7A00] shrink-0" />
              <span>24x7 Customer Support</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
