import React from 'react';
import {
  UserCheck,
  Navigation,
  BadgePercent,
  ClockCheck,
  Headphones,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { whyChooseUsData } from '../data/whyChooseUsData';

const iconMap = {
  UserCheck,
  Navigation,
  BadgePercent,
  ClockCheck,
  Headphones,
  ShieldCheck
};

export default function WhyChooseUs() {
  return (
    <section className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#0057B8] bg-blue-50 px-3.5 py-1.5 rounded-full mb-3">
            Why Choose K R Packers &amp; Movers
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Built on Trust, Precision, and Customer Care
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            We don't just move belongings—we transport memories and livelihoods with meticulous safety standards and honest service.
          </p>
        </div>

        {/* 6 Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {whyChooseUsData.map((item) => {
            const Icon = iconMap[item.iconName] || ShieldCheck;
            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-8 border border-slate-200/90 shadow-soft shadow-soft-hover flex flex-col justify-between group"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-orange-50 text-[#FF7A00] flex items-center justify-center mb-6 group-hover:bg-[#FF7A00] group-hover:text-white transition-colors duration-200">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="inline-block text-xs font-semibold text-[#0057B8] bg-blue-50/80 px-2.5 py-0.5 rounded-md mb-3">
                    {item.highlight}
                  </span>
                  <h3 className="text-xl font-bold text-[#1E293B] mb-3 group-hover:text-[#0057B8] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-2 text-xs font-medium text-slate-500">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>K R Quality Benchmark</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
