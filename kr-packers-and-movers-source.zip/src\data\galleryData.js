export const galleryData = [
  {
    id: 1,
    title: "Enclosed Container Fleet",
    category: "Transport",
    image: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1000&q=80",
    description: "Weather-proof GPS-tracked container trucks ready for long-distance transit across Kerala."
  },
  {
    id: 2,
    title: "Multi-Layer Cushion Packing",
    category: "Packing",
    image: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1000&q=80",
    description: "Organized carton packaging with room categorization and heavy-duty bubble padding."
  },
  {
    id: 3,
    title: "CCTV Monitored Warehouse",
    category: "Storage",
    image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1000&q=80",
    description: "Modern pallet racking and climate-controlled storage hub located in Kochi."
  },
  {
    id: 4,
    title: "Heavy Cargo Loading",
    category: "Loading",
    image: "https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&w=1000&q=80",
    description: "Systematic stacking and weight-balanced loading by certified crew leads."
  },
  {
    id: 5,
    title: "Professional Moving Supplies",
    category: "Packing",
    image: "https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=1000&q=80",
    description: "Export-grade corrugated boxes, edge-protectors, stretch film, and high-tack tape."
  },
  {
    id: 6,
    title: "Safe Vehicle Logistics",
    category: "Transport",
    image: "https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=1000&q=80",
    description: "Dedicated wheel-locked car carriers and ramps preventing road vibrations and dents."
  }
];
