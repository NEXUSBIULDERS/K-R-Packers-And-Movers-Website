import React, { useState, useEffect, useRef } from 'react';
import { statisticsData } from '../data/statisticsData';

function AnimatedNumber({ target, suffix = '+' }) {
  const [count, setCount] = useState(0);
  const elementRef = useRef(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    let animationFrameId = null;

    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          observer.disconnect();

          const duration = 1400; // 1.4s
          const startTime = performance.now();

          const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Ease out quad
            const easeOutProgress = 1 - Math.pow(1 - progress, 3);
            const currentCount = Math.floor(easeOutProgress * target);

            setCount(currentCount);

            if (progress < 1) {
              animationFrameId = requestAnimationFrame(animate);
            } else {
              setCount(target);
            }
          };

          animationFrameId = requestAnimationFrame(animate);
        }
      },
      { threshold: 0.2 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => {
      observer.disconnect();
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [target]);

  return (
    <span ref={elementRef} className="tabular-nums">
      {count.toLocaleString('en-IN')}
      {suffix}
    </span>
  );
}

export default function Statistics() {
  return (
    <section className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Subtle brand tint background */}
      <div className="absolute inset-0 bg-[#0057B8]/15 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-wider font-bold text-[#FF7A00] mb-2 block">
            Proven Track Record
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Our Milestones Speak for Themselves
          </h2>
          <p className="mt-3 text-slate-300 text-sm sm:text-base">
            Consistently delivering reliable, damage-free moves throughout Kerala and across India.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {statisticsData.map((stat) => (
            <div
              key={stat.id}
              className="bg-white/5 border border-white/10 rounded-2xl p-8 text-center shadow-soft hover:border-white/20 transition-all duration-200"
            >
              <div className="text-4xl sm:text-5xl lg:text-5xl font-extrabold tracking-tight mb-2 text-[#FF7A00]">
                <AnimatedNumber target={stat.targetValue} suffix={stat.suffix} />
              </div>
              <h3 className="text-lg font-bold text-slate-100 mb-1">
                {stat.label}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {stat.subtext}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
