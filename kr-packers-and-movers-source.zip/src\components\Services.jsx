import React from 'react';
import {
  Home,
  Building2,
  PackageCheck,
  PackageOpen,
  ArrowUpRightSquare,
  ArrowDownLeftSquare,
  Truck,
  Warehouse,
  Check,
  ArrowRight
} from 'lucide-react';
import { servicesData } from '../data/servicesData';

// Map icon string names to actual Lucide components
const iconMap = {
  Home,
  Building2,
  PackageCheck,
  PackageOpen,
  ArrowUpRightSquare,
  ArrowDownLeftSquare,
  Truck,
  Warehouse
};

export default function Services({ onSelectService }) {
  return (
    <section id="services" className="py-20 lg:py-28 bg-white border-y border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#FF7A00] bg-orange-50 px-3.5 py-1.5 rounded-full mb-3">
            Our Relocation Services
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Comprehensive Moving Solutions in Kerala
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Every relocation is handled by certified specialists using industrial-grade materials and GPS-equipped container fleets.
          </p>
        </div>

        {/* 8 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {servicesData.map((service) => {
            const IconComponent = iconMap[service.iconName] || Truck;
            return (
              <div
                key={service.id}
                className="bg-[#F8FAFC] rounded-2xl p-7 border border-slate-200/90 shadow-soft shadow-soft-hover flex flex-col justify-between group"
              >
                <div>
                  {/* Top Bar with Icon and Badge */}
                  <div className="flex items-start justify-between mb-6">
                    <div className="w-13 h-13 w-12 h-12 rounded-xl bg-blue-50 text-[#0057B8] flex items-center justify-center group-hover:bg-[#0057B8] group-hover:text-white transition-colors duration-200">
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full bg-white border border-slate-200 text-[#0057B8]">
                      {service.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xl font-bold text-[#1E293B] mb-2.5 group-hover:text-[#0057B8] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-5">
                    {service.shortDesc}
                  </p>

                  {/* Bullet Highlights */}
                  <ul className="space-y-2 mb-6 border-t border-slate-200/80 pt-4">
                    {service.features.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                        <Check className="w-3.5 h-3.5 text-[#FF7A00] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card CTA */}
                <a
                  href="#quote"
                  onClick={() => onSelectService && onSelectService(service.title)}
                  className="mt-2 inline-flex items-center justify-between w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-[#0057B8] bg-white hover:bg-[#0057B8] hover:text-white border border-slate-200/80 shadow-xs transition-colors"
                >
                  <span>Request Estimate</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner */}
        <div className="mt-14 bg-gradient-to-r from-blue-50 via-white to-orange-50 rounded-2xl p-6 sm:p-8 border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl">
            <h4 className="text-lg font-bold text-[#1E293B]">
              Need a Customized Relocation Package?
            </h4>
            <p className="text-sm text-slate-600 mt-1">
              Have unique requirements like piano moving, heavy machinery, or split pickup locations across Kerala? Speak to our move coordinators.
            </p>
          </div>
          <div className="shrink-0 flex items-center gap-3">
            <a
              href="#quote"
              className="inline-flex items-center justify-center px-6 py-3 rounded-xl text-sm font-semibold text-white bg-[#0057B8] hover:bg-[#004694] shadow-sm transition-colors"
            >
              Custom Moving Quote
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
