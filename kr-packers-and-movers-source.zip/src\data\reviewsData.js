export const reviewsData = [
  {
    id: 1,
    name: "Dr. Suresh Menon",
    role: "Relocated from Kochi to Bangalore",
    rating: 5,
    date: "12 Oct 2026",
    comment: "Shifting our 3 BHK home from Marine Drive, Kochi to Bangalore was completely stress-free with K R Packers & Movers. Their packing crew arrived right on time with high-quality bubble sheets and corrugated rolls. Even our delicate antique wooden furniture and glass cabinets arrived without a single scratch. Outstanding service!",
    serviceType: "Inter-State Household Shifting",
    avatarInitial: "SM"
  },
  {
    id: 2,
    name: "Ananya Nair",
    role: "Relocated within Thiruvananthapuram",
    rating: 5,
    date: "28 Sep 2026",
    comment: "Moved from Kazhakoottam to Kowdiar. What impressed me most was their transparency—no hidden handling fees or sudden price increases on moving day. The team was polite, neat, and completed both loading and re-assembling our beds and wardrobes within half a day. Highly recommended for family moves in Kerala!",
    serviceType: "Local Villa Relocation",
    avatarInitial: "AN"
  },
  {
    id: 3,
    name: "Mohammed Faizal",
    role: "Operations Head, FinTech Hub Kozhikode",
    rating: 5,
    date: "04 Nov 2026",
    comment: "We hired K R Packers & Movers to shift our 45-seat corporate tech office from Mavoor Road to Cyberpark Kozhikode. Over 50 workstations, monitors, servers, and executive chairs were packed with anti-static wrap and transported seamlessly over a weekend. We resumed work on Monday with zero downtime.",
    serviceType: "Corporate Office Shifting",
    avatarInitial: "MF"
  }
];
