export const statisticsData = [
  {
    id: "experience",
    targetValue: 10,
    suffix: "+",
    label: "Years Experience",
    subtext: "Delivering trust & excellence across Kerala since 2014"
  },
  {
    id: "customers",
    targetValue: 8000,
    suffix: "+",
    label: "Happy Customers",
    subtext: "Families & businesses relocated with top satisfaction"
  },
  {
    id: "deliveries",
    targetValue: 12000,
    suffix: "+",
    label: "Successful Deliveries",
    subtext: "Local and inter-state consignments safely delivered"
  },
  {
    id: "staff",
    targetValue: 150,
    suffix: "+",
    label: "Professional Staff",
    subtext: "Trained packers, certified drivers & move managers"
  }
];
