import React, { useState, useEffect } from 'react';
import { Phone, MessageCircle, Menu, X, Truck, ShieldCheck, MapPin } from 'lucide-react';
import { companyData } from '../data/companyData';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setIsScrolled(window.scrollY > 20);
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on Escape key press
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mobileMenuOpen]);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full transition-all duration-200">
      {/* Top Utility Bar */}
      <div className="bg-[#1E293B] text-slate-200 text-xs py-2 px-4 border-b border-slate-700/60 hidden sm:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-[#FF7A00]" />
              Serving All 14 Districts in Kerala &amp; Pan-India
            </span>
            <span className="hidden md:flex items-center gap-1.5 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              10+ Years of Verified Safe Relocations
            </span>
          </div>
          <div className="flex items-center gap-5">
            <a
              href={`tel:${companyData.phoneClean}`}
              className="flex items-center gap-1.5 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#FF7A00] rounded"
            >
              <Phone className="w-3.5 h-3.5 text-[#FF7A00]" />
              <span>24x7 Helpline: {companyData.phone}</span>
            </a>
            <a
              href={companyData.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-emerald-300 transition-colors text-emerald-400 font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-emerald-400 rounded"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav
        aria-label="Main Navigation"
        className={`w-full transition-all duration-200 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-md py-3.5'
            : 'bg-white shadow-sm py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            className="flex items-center gap-3 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8] rounded-xl p-1"
          >
            <div className="w-11 h-11 rounded-xl bg-[#0057B8] flex items-center justify-center text-white shadow-sm group-hover:bg-[#004694] transition-colors">
              <Truck className="w-6 h-6 text-[#FF7A00]" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-[#1E293B] leading-none">
                K R <span className="text-[#0057B8]">PACKERS</span>
              </span>
              <span className="text-[11px] font-semibold text-[#FF7A00] tracking-wider uppercase mt-1">
                &amp; Movers Kerala
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-[#1E293B] hover:text-[#0057B8] transition-colors relative py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8] rounded-md px-1"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Right Action Buttons */}
          <div className="hidden lg:flex items-center gap-4">
            <a
              href={`tel:${companyData.phoneClean}`}
              className="flex items-center gap-2 text-sm font-semibold text-[#1E293B] hover:text-[#0057B8] transition-colors px-3 py-2 rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8]"
            >
              <Phone className="w-4 h-4 text-[#FF7A00]" />
              <span>{companyData.phone}</span>
            </a>
            <a
              href="#quote"
              className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#0057B8] hover:bg-[#004694] active:scale-[0.98] shadow-sm transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#0057B8]"
            >
              Get Quote
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex lg:hidden items-center gap-3">
            <a
              href="#quote"
              className="text-xs font-semibold px-3 py-2 rounded-lg text-white bg-[#0057B8] hover:bg-[#004694]"
            >
              Get Quote
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="p-2.5 rounded-lg text-[#1E293B] hover:bg-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8]"
              aria-label="Toggle Navigation Menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-100 bg-white px-4 pt-3 pb-6 shadow-xl animate-in fade-in duration-150">
            <div className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 text-base font-medium text-[#1E293B] hover:text-[#0057B8] hover:bg-slate-50 rounded-lg transition-colors"
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-3 border-t border-slate-100 flex flex-col gap-2.5">
                <a
                  href={`tel:${companyData.phoneClean}`}
                  className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-slate-200 text-sm font-semibold text-[#1E293B] bg-slate-50 active:bg-slate-100"
                >
                  <Phone className="w-4 h-4 text-[#FF7A00]" />
                  <span>Call {companyData.phone}</span>
                </a>
                <a
                  href="#quote"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-center py-3.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#0057B8] active:bg-[#004694]"
                >
                  Get Free Estimate
                </a>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
