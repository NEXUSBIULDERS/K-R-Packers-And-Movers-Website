import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import { companyData } from '../data/companyData';

export default function FloatingActions() {
  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-none">
      {/* Floating Call Button */}
      <a
        href={`tel:${companyData.phoneClean}`}
        className="pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#0057B8] hover:bg-[#004694] text-white shadow-lg hover:shadow-xl transition-all duration-200 group active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
        aria-label="Call K R Packers & Movers"
        title="Call 24x7 Helpline"
      >
        <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
          <Phone className="w-3.5 h-3.5 text-white" />
        </div>
        <span className="text-xs font-bold hidden sm:inline-block pr-1">
          Call Now
        </span>
      </a>

      {/* Floating WhatsApp Button */}
      <a
        href={companyData.whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 group active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
        aria-label="Chat on WhatsApp with K R Packers & Movers"
        title="Chat on WhatsApp (6282559957)"
      >
        <div className="relative">
          <MessageCircle className="w-6 h-6 text-white" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#FF7A00] rounded-full border-2 border-white" />
        </div>
        <span className="text-xs font-bold hidden sm:inline-block pr-1">
          WhatsApp Us
        </span>
      </a>
    </div>
  );
}
