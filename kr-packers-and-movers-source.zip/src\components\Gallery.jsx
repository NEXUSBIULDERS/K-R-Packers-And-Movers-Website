import React, { useState, useEffect } from 'react';
import { galleryData } from '../data/galleryData';
import { ZoomIn, X } from 'lucide-react';

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeImage, setActiveImage] = useState(null);

  const categories = ['All', 'Transport', 'Packing', 'Storage', 'Loading'];

  const filteredImages =
    activeCategory === 'All'
      ? galleryData
      : galleryData.filter((item) => item.category === activeCategory);

  // Lock body scroll and listen for Escape key when lightbox is open
  useEffect(() => {
    if (activeImage) {
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e) => {
        if (e.key === 'Escape') {
          setActiveImage(null);
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [activeImage]);

  return (
    <section id="gallery" className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#FF7A00] bg-orange-50 px-3.5 py-1.5 rounded-full mb-3">
            Our Work in Action
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Relocation &amp; Fleet Gallery
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Take a closer look at our well-maintained container trucks, professional multi-layer packing standards, and safe warehouse facilities.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              type="button"
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8] ${
                activeCategory === cat
                  ? 'bg-[#0057B8] text-white shadow-sm'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Responsive Image Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredImages.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveImage(item)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setActiveImage(item);
                }
              }}
              className="group cursor-pointer bg-white rounded-2xl overflow-hidden border border-slate-200/90 shadow-soft shadow-soft-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8]"
              aria-label={`View photo: ${item.title}`}
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  loading="lazy"
                  decoding="async"
                  width="600"
                  height="450"
                />
                <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="p-3 bg-white/90 rounded-full text-slate-900 shadow-sm">
                    <ZoomIn className="w-5 h-5 text-[#0057B8]" />
                  </span>
                </div>
                <div className="absolute top-3 left-3">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full bg-white/95 text-[#0057B8] shadow-xs">
                    {item.category}
                  </span>
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-bold text-[#1E293B] text-base group-hover:text-[#0057B8] transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {activeImage && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs animate-in fade-in duration-150"
            onClick={() => setActiveImage(null)}
            role="dialog"
            aria-modal="true"
          >
            <div
              className="relative max-w-3xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setActiveImage(null)}
                className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-slate-900/75 text-white hover:bg-slate-900 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                aria-label="Close Preview (Press Escape)"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={activeImage.image}
                alt={activeImage.title}
                className="w-full max-h-[70vh] object-cover"
                decoding="async"
              />
              <div className="p-6">
                <span className="text-xs font-bold uppercase tracking-wider text-[#FF7A00]">
                  {activeImage.category}
                </span>
                <h3 className="text-xl font-bold text-[#1E293B] mt-1">
                  {activeImage.title}
                </h3>
                <p className="text-sm text-slate-600 mt-2">
                  {activeImage.description}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
