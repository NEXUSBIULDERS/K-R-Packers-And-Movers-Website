import React, { useState } from 'react';
import {
  Calculator,
  CheckCircle2,
  Phone,
  MessageCircle,
  Calendar,
  MapPin,
  Home,
  User,
  FileText,
  AlertCircle
} from 'lucide-react';
import { companyData } from '../data/companyData';

// Today's minimum selectable date calculated once at module load
const TODAY_STRING = new Date().toISOString().split('T')[0];

export default function QuoteForm({ selectedService }) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    pickupLocation: '',
    dropLocation: '',
    houseType: selectedService || '2 BHK Apartment / House',
    movingDate: '',
    message: ''
  });

  const [quoteSubmitted, setQuoteSubmitted] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Common Kerala relocation hubs for quick click
  const quickLocations = ['Kochi', 'Thiruvananthapuram', 'Kozhikode', 'Thrissur', 'Bangalore', 'Coimbatore'];

  const houseTypeOptions = [
    '1 RK / Studio',
    '1 BHK Apartment / House',
    '2 BHK Apartment / House',
    '3 BHK Apartment / House',
    '4+ BHK / Independent Villa',
    'Commercial / Corporate Office',
    'Single Vehicle (Car / Bike) Transport',
    'Warehouse Storage Facility'
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errorMsg) setErrorMsg('');
  };

  const handleQuickPickup = (city) => {
    setFormData((prev) => ({ ...prev, pickupLocation: city }));
  };

  const handleQuickDrop = (city) => {
    setFormData((prev) => ({ ...prev, dropLocation: city }));
  };

  const handleSubmitQuote = (e) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.phone.trim() || !formData.pickupLocation.trim() || !formData.dropLocation.trim() || !formData.movingDate) {
      setErrorMsg('Please fill in all required fields (Name, Phone, Pickup, Drop, Moving Date).');
      return;
    }

    const cleanPhone = formData.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setQuoteSubmitted({
        referenceId: 'KR-' + Math.floor(100000 + Math.random() * 900000),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
    }, 300);
  };

  const generateWhatsAppMessage = () => {
    const ref = quoteSubmitted?.referenceId || 'ONLINE-QUOTE';
    const text = `*New Relocation Inquiry - K R Packers & Movers*\n\n` +
      `*Reference:* #${ref}\n` +
      `*Name:* ${formData.name}\n` +
      `*Phone:* ${formData.phone}\n` +
      `*Pickup Location:* ${formData.pickupLocation}\n` +
      `*Drop Location:* ${formData.dropLocation}\n` +
      `*Move Type:* ${formData.houseType}\n` +
      `*Moving Date:* ${formData.movingDate}\n` +
      (formData.message ? `*Notes:* ${formData.message}\n` : '') +
      `\nPlease contact me with quotation and availability.`;

    return `https://wa.me/916282559957?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="quote" className="py-20 lg:py-28 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-block text-xs uppercase tracking-wider font-bold text-[#0057B8] bg-blue-50 px-3.5 py-1.5 rounded-full mb-3">
            Free Relocation Quote
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E293B] tracking-tight">
            Request Your Moving Estimate
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Fill in your moving details below. Our team will review your route and inventory to provide a transparent, personalized quote.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Main Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-soft p-6 sm:p-10">
            {quoteSubmitted ? (
              /* Success Confirmation Display (No Final Pricing or Moving Charge) */
              <div className="text-center py-6">
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400">
                  Inquiry Reference: #{quoteSubmitted.referenceId}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-[#1E293B] mt-2 mb-2">
                  Relocation Request Received!
                </h3>
                <p className="text-sm text-slate-600 max-w-lg mx-auto">
                  Thank you, <span className="font-semibold text-slate-900">{formData.name}</span>. We have captured your moving requirements. Connect with us on WhatsApp for an immediate customized quote tailored to your items.
                </p>

                {/* Summary Table */}
                <div className="my-6 grid grid-cols-2 sm:grid-cols-4 gap-3 text-left max-w-xl mx-auto bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-400 block font-medium">Client:</span>
                    <span className="font-semibold text-slate-800">{formData.name}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Type:</span>
                    <span className="font-semibold text-slate-800">{formData.houseType}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Route:</span>
                    <span className="font-semibold text-slate-800">{formData.pickupLocation} → {formData.dropLocation}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Moving Date:</span>
                    <span className="font-semibold text-slate-800">{formData.movingDate}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
                  <a
                    href={generateWhatsAppMessage()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] shadow-sm transition-all text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>Send on WhatsApp (6282559957)</span>
                  </a>
                  <a
                    href={`tel:${companyData.phoneClean}`}
                    className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 active:scale-[0.98] border border-slate-300 transition-all text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                  >
                    <Phone className="w-4 h-4 text-[#FF7A00]" />
                    <span>Call Move Manager</span>
                  </a>
                </div>

                <button
                  type="button"
                  onClick={() => setQuoteSubmitted(null)}
                  className="mt-6 text-xs font-semibold text-[#0057B8] hover:underline"
                >
                  ← Submit another inquiry
                </button>
              </div>
            ) : (
              /* The Input Form */
              <form onSubmit={handleSubmitQuote} noValidate>
                {errorMsg && (
                  <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 flex items-center gap-3 text-sm text-red-700">
                    <AlertCircle className="w-5 h-5 shrink-0 text-red-500" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Name */}
                  <div>
                    <label htmlFor="quote-name" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Full Name *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        id="quote-name"
                        type="text"
                        name="name"
                        autoComplete="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="e.g. Rahul Varma"
                        required
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  {/* Phone */}
                  <div>
                    <label htmlFor="quote-phone" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Phone Number *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Phone className="w-4 h-4" />
                      </div>
                      <input
                        id="quote-phone"
                        type="tel"
                        name="phone"
                        autoComplete="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="e.g. 98470 12345"
                        required
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  {/* Pickup Location */}
                  <div>
                    <label htmlFor="quote-pickup" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Pickup Location *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <MapPin className="w-4 h-4 text-[#0057B8]" />
                      </div>
                      <input
                        id="quote-pickup"
                        type="text"
                        name="pickupLocation"
                        value={formData.pickupLocation}
                        onChange={handleChange}
                        placeholder="e.g. Kochi, Kakkanad"
                        required
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all"
                      />
                    </div>
                    {/* Quick Pick Chips */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className="text-[11px] text-slate-500 font-medium">Quick:</span>
                      {quickLocations.slice(0, 4).map((city) => (
                        <button
                          key={city}
                          type="button"
                          onClick={() => handleQuickPickup(city)}
                          className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                        >
                          {city}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Drop Location */}
                  <div>
                    <label htmlFor="quote-drop" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Drop Location *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <MapPin className="w-4 h-4 text-[#FF7A00]" />
                      </div>
                      <input
                        id="quote-drop"
                        type="text"
                        name="dropLocation"
                        value={formData.dropLocation}
                        onChange={handleChange}
                        placeholder="e.g. Trivandrum, Kowdiar"
                        required
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all"
                      />
                    </div>
                    {/* Quick Pick Chips */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className="text-[11px] text-slate-500 font-medium">Quick:</span>
                      {quickLocations.map((city) => (
                        <button
                          key={city}
                          type="button"
                          onClick={() => handleQuickDrop(city)}
                          className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                        >
                          {city}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* House Type */}
                  <div>
                    <label htmlFor="quote-type" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      House Type / Move Size *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Home className="w-4 h-4" />
                      </div>
                      <select
                        id="quote-type"
                        name="houseType"
                        value={formData.houseType}
                        onChange={handleChange}
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all"
                      >
                        {houseTypeOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Moving Date */}
                  <div>
                    <label htmlFor="quote-date" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Moving Date *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Calendar className="w-4 h-4" />
                      </div>
                      <input
                        id="quote-date"
                        type="date"
                        name="movingDate"
                        min={TODAY_STRING}
                        value={formData.movingDate}
                        onChange={handleChange}
                        required
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  {/* Message */}
                  <div className="md:col-span-2">
                    <label htmlFor="quote-message" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Additional Message / Special Items (Optional)
                    </label>
                    <div className="relative">
                      <div className="absolute top-3 left-3.5 pointer-events-none text-slate-400">
                        <FileText className="w-4 h-4" />
                      </div>
                      <textarea
                        id="quote-message"
                        name="message"
                        rows="3"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Mention any large electronics, delicate chinaware, piano, or lift accessibility..."
                        className="w-full pl-10 pr-4 py-3 bg-[#F8FAFC] border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0057B8] focus:border-transparent transition-all resize-y"
                      ></textarea>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-xs text-slate-500 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>Free personalized estimate • No spam calls • Privacy protected</span>
                  </div>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl font-semibold text-white bg-[#0057B8] hover:bg-[#004694] active:scale-[0.99] shadow-sm transition-all duration-150 text-sm disabled:opacity-70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0057B8]"
                  >
                    <Calculator className="w-4 h-4" />
                    <span>{isSubmitting ? 'Submitting...' : 'Get Estimate'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
