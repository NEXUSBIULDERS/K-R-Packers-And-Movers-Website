export const whyChooseUsData = [
  {
    id: "professional-staff",
    title: "Professional Staff",
    description: "Background-verified, uniform-clad crew trained in modern packing techniques, heavy lifting safety, and respectful customer etiquette.",
    iconName: "UserCheck",
    highlight: "100% Verified Crew"
  },
  {
    id: "gps-tracked-vehicles",
    title: "GPS Tracked Vehicles",
    description: "Every truck in our fleet is equipped with real-time GPS tracking. Receive live route updates and know the exact ETA of your shipment.",
    iconName: "Navigation",
    highlight: "Real-time Live Location"
  },
  {
    id: "affordable-pricing",
    title: "Affordable Pricing",
    description: "Transparent written estimates with clear itemization. No hidden charges on moving day, no surprise toll charges or unmentioned costs.",
    iconName: "BadgePercent",
    highlight: "No Hidden Costs"
  },
  {
    id: "on-time-delivery",
    title: "On Time Delivery",
    description: "Punctual pickup schedules and disciplined transit timelines across all 14 districts in Kerala and major South Indian highways.",
    iconName: "ClockCheck",
    highlight: "99.4% On-Time Record"
  },
  {
    id: "support-24-7",
    title: "24×7 Support",
    description: "A dedicated move coordinator assigned to your booking. Call or WhatsApp our helpline round-the-clock for instant assistance.",
    iconName: "Headphones",
    highlight: "Dedicated Move Manager"
  },
  {
    id: "damage-protection",
    title: "Damage Protection",
    description: "Comprehensive goods-in-transit protection and tamper-proof safety packaging to ensure 100% intact handover of every item.",
    iconName: "ShieldCheck",
    highlight: "Comprehensive Transit Cover"
  }
];
