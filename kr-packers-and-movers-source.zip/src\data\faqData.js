export const faqData = [
  {
    question: "How early should I book K R Packers & Movers for my shifting?",
    answer: "We recommend scheduling your move 3 to 7 days in advance for local shifting within Kerala, and 7 to 10 days ahead for inter-state moves. However, if you require urgent or emergency same-day shifting in Kochi, Trivandrum, or Kozhikode, our customer helpline is ready to accommodate you subject to fleet availability."
  },
  {
    question: "How do you protect fragile items like glassware, TVs, and wooden antiques?",
    answer: "We follow a 4-tier packing protocol: First, items are individually bubble-wrapped; second, corners are shielded with rigid foam protectors; third, they are secured inside double-walled corrugated boxes; and fourth, high-value or glass items receive custom wooden crating. All electronics are transported in shock-absorbent upright positions."
  },
  {
    question: "Are there any hidden costs or surprise handling fees on moving day?",
    answer: "None whatsoever. At K R Packers & Movers, our written quotes include packing material, labor charges, loading, transit, toll taxes, and unloading. We believe in 100% price transparency—what is agreed in your initial quotation is strictly what you pay."
  },
  {
    question: "Do you provide insurance / damage protection for moving goods?",
    answer: "Yes, we provide optional comprehensive transit insurance covering up to 100% of declared shipment value against unforeseen accidental transit damage or weather mishaps. Our move coordinator will assist you with straightforward policy documentation prior to dispatch."
  },
  {
    question: "Can you transport my car or two-wheeler along with household items?",
    answer: "Yes, we have specialized enclosed hydraulic car carrier trucks and secured two-wheeler mounts. Your vehicle is thoroughly inspected with pre-dispatch photo documentation, tires safely chocked, and transported door-to-door with real-time GPS tracking."
  },
  {
    question: "What items are prohibited or cannot be packed into moving trucks?",
    answer: "For statutory and fire-safety reasons, we cannot transport hazardous chemicals, open inflammable fuels (kerosene, petrol), gas cylinders (unless completely emptied and certified), currency notes, original gold jewellery, and perishable fresh food. We advise keeping personal jewellery and critical documents in your personal handbag."
  }
];
